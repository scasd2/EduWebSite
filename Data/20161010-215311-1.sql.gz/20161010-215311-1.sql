-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : qdm190766663.my3w.com
-- Port     : 3306
-- Database : qdm190766663_db
-- 
-- Part : #1
-- Date : 2016-10-10 21:53:11
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `onethink_action`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action`;
CREATE TABLE `onethink_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `onethink_action`
-- -----------------------------
INSERT INTO `onethink_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `onethink_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `onethink_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `onethink_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `onethink_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `onethink_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `onethink_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `onethink_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `onethink_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `onethink_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `onethink_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `onethink_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action_log`;
CREATE TABLE `onethink_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `onethink_action_log`
-- -----------------------------
INSERT INTO `onethink_action_log` VALUES ('1', '1', '1', '2130706433', 'member', '1', 'Administrator在2016-10-09 22:39登录了后台', '1', '1476023981');
INSERT INTO `onethink_action_log` VALUES ('2', '1', '1', '2130706433', 'member', '1', 'Administrator在2016-10-10 12:08登录了后台', '1', '1476072530');
INSERT INTO `onethink_action_log` VALUES ('3', '11', '1', '2130706433', 'category', '2', '操作url：/EduWebSite/index.php?s=/Admin/Category/remove/id/2.html', '1', '1476072651');
INSERT INTO `onethink_action_log` VALUES ('4', '11', '1', '2130706433', 'category', '1', '操作url：/EduWebSite/index.php?s=/Admin/Category/remove/id/1.html', '1', '1476072657');
INSERT INTO `onethink_action_log` VALUES ('5', '11', '1', '2130706433', 'category', '39', '操作url：/EduWebSite/index.php?s=/Admin/Category/add.html', '1', '1476072724');
INSERT INTO `onethink_action_log` VALUES ('6', '11', '1', '2130706433', 'category', '39', '操作url：/EduWebSite/index.php?s=/Admin/Category/edit.html', '1', '1476072862');
INSERT INTO `onethink_action_log` VALUES ('7', '11', '1', '2130706433', 'category', '39', '操作url：/EduWebSite/index.php?s=/Admin/Category/edit.html', '1', '1476072933');
INSERT INTO `onethink_action_log` VALUES ('8', '11', '1', '2130706433', 'category', '39', '操作url：/EduWebSite/index.php?s=/Admin/Category/edit.html', '1', '1476072943');
INSERT INTO `onethink_action_log` VALUES ('9', '11', '1', '2130706433', 'category', '39', '操作url：/EduWebSite/index.php?s=/Admin/Category/edit.html', '1', '1476073087');
INSERT INTO `onethink_action_log` VALUES ('10', '11', '1', '2130706433', 'category', '39', '操作url：/EduWebSite/index.php?s=/Admin/Category/edit.html', '1', '1476073147');
INSERT INTO `onethink_action_log` VALUES ('11', '11', '1', '2130706433', 'category', '39', '操作url：/EduWebSite/index.php?s=/Admin/Category/remove/id/39.html', '1', '1476073158');
INSERT INTO `onethink_action_log` VALUES ('12', '11', '1', '2130706433', 'category', '40', '操作url：/EduWebSite/index.php?s=/Admin/Category/add.html', '1', '1476073187');
INSERT INTO `onethink_action_log` VALUES ('13', '11', '1', '2130706433', 'category', '41', '操作url：/EduWebSite/index.php?s=/Admin/Category/add.html', '1', '1476073306');
INSERT INTO `onethink_action_log` VALUES ('14', '11', '1', '2130706433', 'category', '42', '操作url：/EduWebSite/index.php?s=/Admin/Category/add.html', '1', '1476073332');
INSERT INTO `onethink_action_log` VALUES ('15', '11', '1', '2130706433', 'category', '43', '操作url：/EduWebSite/index.php?s=/Admin/Category/add.html', '1', '1476073352');
INSERT INTO `onethink_action_log` VALUES ('16', '7', '1', '2130706433', 'model', '4', '操作url：/EduWebSite/index.php?s=/Admin/Model/update.html', '1', '1476073846');
INSERT INTO `onethink_action_log` VALUES ('17', '8', '1', '2130706433', 'attribute', '33', '操作url：/EduWebSite/index.php?s=/Admin/Attribute/update.html', '1', '1476074132');
INSERT INTO `onethink_action_log` VALUES ('18', '8', '1', '2130706433', 'attribute', '33', '操作url：/EduWebSite/index.php?s=/Admin/Attribute/update.html', '1', '1476074260');
INSERT INTO `onethink_action_log` VALUES ('19', '8', '1', '2130706433', 'attribute', '34', '操作url：/EduWebSite/index.php?s=/Admin/Attribute/update.html', '1', '1476074473');
INSERT INTO `onethink_action_log` VALUES ('20', '8', '1', '2130706433', 'attribute', '35', '操作url：/EduWebSite/index.php?s=/Admin/Attribute/update.html', '1', '1476075397');
INSERT INTO `onethink_action_log` VALUES ('21', '8', '1', '2130706433', 'attribute', '36', '操作url：/EduWebSite/index.php?s=/Admin/Attribute/update.html', '1', '1476075499');
INSERT INTO `onethink_action_log` VALUES ('22', '8', '1', '2130706433', 'attribute', '37', '操作url：/EduWebSite/index.php?s=/Admin/Attribute/update.html', '1', '1476075566');
INSERT INTO `onethink_action_log` VALUES ('23', '8', '1', '2130706433', 'attribute', '38', '操作url：/EduWebSite/index.php?s=/Admin/Attribute/update.html', '1', '1476075660');
INSERT INTO `onethink_action_log` VALUES ('24', '8', '1', '2130706433', 'attribute', '39', '操作url：/EduWebSite/index.php?s=/Admin/Attribute/update.html', '1', '1476075705');
INSERT INTO `onethink_action_log` VALUES ('25', '1', '1', '2130706433', 'member', '1', 'Administrator在2016-10-10 16:20登录了后台', '1', '1476087624');
INSERT INTO `onethink_action_log` VALUES ('26', '1', '2', '2130706433', 'member', '2', 'admin在2016-10-10 16:42登录了后台', '1', '1476088952');
INSERT INTO `onethink_action_log` VALUES ('27', '1', '2', '2130706433', 'member', '2', 'admin在2016-10-10 16:44登录了后台', '1', '1476089054');
INSERT INTO `onethink_action_log` VALUES ('28', '1', '2', '2130706433', 'member', '2', 'admin在2016-10-10 16:45登录了后台', '1', '1476089150');
INSERT INTO `onethink_action_log` VALUES ('29', '1', '1', '2013188447', 'member', '1', 'Administrator在2016-10-10 17:52登录了后台', '1', '1476093174');
INSERT INTO `onethink_action_log` VALUES ('30', '1', '1', '1879436323', 'member', '1', 'Administrator在2016-10-10 19:01登录了后台', '1', '1476097293');
INSERT INTO `onethink_action_log` VALUES ('31', '1', '1', '3704105796', 'member', '1', 'Administrator在2016-10-10 19:01登录了后台', '1', '1476097314');
INSERT INTO `onethink_action_log` VALUES ('32', '1', '1', '2130706433', 'member', '1', 'Administrator在2016-10-10 19:15登录了后台', '1', '1476098141');
INSERT INTO `onethink_action_log` VALUES ('33', '7', '1', '2130706433', 'model', '4', '操作url：/EduWebSite/index.php?s=/Admin/Model/update.html', '1', '1476098388');
INSERT INTO `onethink_action_log` VALUES ('34', '7', '1', '2130706433', 'model', '4', '操作url：/EduWebSite/index.php?s=/Admin/Model/update.html', '1', '1476098907');
INSERT INTO `onethink_action_log` VALUES ('35', '7', '1', '2130706433', 'model', '4', '操作url：/EduWebSite/index.php?s=/Admin/Model/update.html', '1', '1476098941');
INSERT INTO `onethink_action_log` VALUES ('36', '9', '1', '2130706433', 'channel', '0', '操作url：/EduWebSite/index.php?s=/Admin/Channel/del/id/2.html', '1', '1476101071');
INSERT INTO `onethink_action_log` VALUES ('37', '9', '1', '2130706433', 'channel', '0', '操作url：/EduWebSite/index.php?s=/Admin/Channel/del/id/3.html', '1', '1476101081');
INSERT INTO `onethink_action_log` VALUES ('38', '7', '1', '1879436323', 'model', '5', '操作url：/index.php?s=/Admin/Model/update.html', '1', '1476101131');
INSERT INTO `onethink_action_log` VALUES ('39', '9', '1', '2130706433', 'channel', '4', '操作url：/EduWebSite/index.php?s=/Admin/Channel/edit.html', '1', '1476101129');
INSERT INTO `onethink_action_log` VALUES ('40', '8', '1', '1879436323', 'attribute', '50', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476102253');
INSERT INTO `onethink_action_log` VALUES ('41', '8', '1', '1879436323', 'attribute', '51', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476102378');
INSERT INTO `onethink_action_log` VALUES ('42', '7', '1', '1879436323', 'model', '5', '操作url：/index.php?s=/Admin/Model/update.html', '1', '1476102453');
INSERT INTO `onethink_action_log` VALUES ('43', '7', '1', '1879436323', 'model', '5', '操作url：/index.php?s=/Admin/Model/update.html', '1', '1476102489');
INSERT INTO `onethink_action_log` VALUES ('44', '8', '1', '1879436323', 'attribute', '52', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476102529');
INSERT INTO `onethink_action_log` VALUES ('45', '8', '1', '1879436323', 'attribute', '53', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476102573');
INSERT INTO `onethink_action_log` VALUES ('46', '8', '1', '1879436323', 'attribute', '54', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476102647');
INSERT INTO `onethink_action_log` VALUES ('47', '8', '1', '1879436323', 'attribute', '55', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476102702');
INSERT INTO `onethink_action_log` VALUES ('48', '8', '1', '1879436323', 'attribute', '56', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476103060');
INSERT INTO `onethink_action_log` VALUES ('49', '8', '1', '1879436323', 'attribute', '57', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476103112');
INSERT INTO `onethink_action_log` VALUES ('50', '8', '1', '1879436323', 'attribute', '58', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476103172');
INSERT INTO `onethink_action_log` VALUES ('51', '8', '1', '1879436323', 'attribute', '59', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476103311');
INSERT INTO `onethink_action_log` VALUES ('52', '8', '1', '1879436323', 'attribute', '60', '操作url：/index.php?s=/Admin/Attribute/update.html', '1', '1476103474');

-- -----------------------------
-- Table structure for `onethink_addons`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_addons`;
CREATE TABLE `onethink_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `onethink_addons`
-- -----------------------------
INSERT INTO `onethink_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `onethink_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `onethink_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `onethink_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `onethink_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `onethink_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `onethink_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');

-- -----------------------------
-- Table structure for `onethink_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attachment`;
CREATE TABLE `onethink_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `onethink_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attribute`;
CREATE TABLE `onethink_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `onethink_attribute`
-- -----------------------------
INSERT INTO `onethink_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '1:列表推荐\r\n2:频道页推荐\r\n4:首页推荐', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('33', 'grade', '年级', 'char(50) NOT NULL', 'select', '0', '', '1', '0:小学\r\n1:初中\r\n2:高中', '4', '1', '1', '1476074261', '1476074133', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('34', 'subject', '科目', 'char(50) NOT NULL', 'select', '0', '', '1', '0:语文\r\n1:数学\r\n2:英语\r\n3:历史\r\n4:地理\r\n5:生物\r\n6:政治\r\n7:化学\r\n8:物理', '4', '1', '1', '1476074473', '1476074473', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('35', 'head', '头像', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '4', '1', '1', '1476075398', '1476075398', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('36', 'name', '姓名', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '4', '1', '1', '1476075500', '1476075500', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('37', 'desc', '简介', 'text NOT NULL', 'textarea', '', '请输入教师简介', '1', '', '4', '1', '1', '1476075566', '1476075566', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('38', 'style', '教学风格', 'text NOT NULL', 'textarea', '', '', '1', '', '4', '1', '1', '1476075660', '1476075660', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('39', 'achievement', '教学成果', 'text NOT NULL', 'textarea', '', '', '1', '', '4', '1', '1', '1476075706', '1476075706', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('50', 'SchoolName', '学校名称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1476102253', '1476102253', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('51', 'UrbanDistrict', '城市区域', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1476102378', '1476102378', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('52', 'SchoolType', '学校类别', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1476102529', '1476102529', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('53', 'SchoolNature', '学校性质', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1476102573', '1476102573', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('54', 'time', '创办时间', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1476102647', '1476102647', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('55', 'website', '学校网址', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1476102702', '1476102702', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('56', 'phone', '联系方式', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '1', '', '5', '0', '1', '1476103060', '1476103060', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('57', 'address', '校区地址', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1476103112', '1476103112', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('58', 'introduce', '学校介绍', 'text NOT NULL', 'textarea', '', '', '1', '', '5', '1', '1', '1476103172', '1476103172', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('59', 'level', '学校级别', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1476103311', '1476103311', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('60', 'picture', '图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '5', '1', '1', '1476103474', '1476103474', '', '3', '', 'regex', '', '3', 'function');

-- -----------------------------
-- Table structure for `onethink_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_extend`;
CREATE TABLE `onethink_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `onethink_auth_extend`
-- -----------------------------
INSERT INTO `onethink_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `onethink_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group`;
CREATE TABLE `onethink_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_group`
-- -----------------------------
INSERT INTO `onethink_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,56,57,58,59,60,79,205,206,208');
INSERT INTO `onethink_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');

-- -----------------------------
-- Table structure for `onethink_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group_access`;
CREATE TABLE `onethink_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_group_access`
-- -----------------------------
INSERT INTO `onethink_auth_group_access` VALUES ('2', '1');

-- -----------------------------
-- Table structure for `onethink_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_rule`;
CREATE TABLE `onethink_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_rule`
-- -----------------------------
INSERT INTO `onethink_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '内容', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');

-- -----------------------------
-- Table structure for `onethink_category`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_category`;
CREATE TABLE `onethink_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `onethink_category`
-- -----------------------------
INSERT INTO `onethink_category` VALUES ('40', 'news', '资讯', '0', '0', '10', '', '', '', '', '', '', '', '', '', '0', '1', '1', '1', '0', '', '', '1476073187', '1476073187', '1', '0');
INSERT INTO `onethink_category` VALUES ('41', 'news-1', '小学', '40', '0', '10', '', '', '', '', '', '', '', '2', '2', '0', '1', '1', '1', '0', '', '', '1476073306', '1476073306', '1', '0');
INSERT INTO `onethink_category` VALUES ('42', 'news-2', '初中', '40', '0', '10', '', '', '', '', '', '', '', '2', '2', '0', '1', '1', '1', '0', '', '', '1476073332', '1476073332', '1', '0');
INSERT INTO `onethink_category` VALUES ('43', 'news-3', '高中', '40', '0', '10', '', '', '', '', '', '', '', '2', '2', '0', '1', '1', '1', '0', '', '', '1476073352', '1476073352', '1', '0');

-- -----------------------------
-- Table structure for `onethink_channel`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_channel`;
CREATE TABLE `onethink_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_channel`
-- -----------------------------
INSERT INTO `onethink_channel` VALUES ('1', '0', '首页', 'Index/index', '1', '1379475111', '1379923177', '1', '0');
INSERT INTO `onethink_channel` VALUES ('4', '0', '老师查询', 'Teacher/index', '2', '1476101109', '1476101129', '1', '0');

-- -----------------------------
-- Table structure for `onethink_config`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_config`;
CREATE TABLE `onethink_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_config`
-- -----------------------------
INSERT INTO `onethink_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', 'OneThink内容管理框架', '0');
INSERT INTO `onethink_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'OneThink内容管理框架', '1');
INSERT INTO `onethink_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'ThinkPHP,OneThink', '8');
INSERT INTO `onethink_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `onethink_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '9');
INSERT INTO `onethink_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐\r\n2:频道页推荐\r\n4:网站首页推荐', '3');
INSERT INTO `onethink_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `onethink_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `onethink_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '4');
INSERT INTO `onethink_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `onethink_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `onethink_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `onethink_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `onethink_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `onethink_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `onethink_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `onethink_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `onethink_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `onethink_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `onethink_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `onethink_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `onethink_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `onethink_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '0');
INSERT INTO `onethink_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `onethink_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');

-- -----------------------------
-- Table structure for `onethink_document`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document`;
CREATE TABLE `onethink_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `onethink_document`
-- -----------------------------
INSERT INTO `onethink_document` VALUES ('3', '1', '', '五大方法养成好的学习习惯，助力小学学习', '41', '', '0', '0', '2', '2', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '1476073542', '1476073542', '1');

-- -----------------------------
-- Table structure for `onethink_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_article`;
CREATE TABLE `onethink_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `onethink_document_article`
-- -----------------------------
INSERT INTO `onethink_document_article` VALUES ('3', '0', '<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">小学阶段的学习，对于孩子学习习惯的养成是十分重要的，小学阶段是学生形成良好学习习惯的关键时刻和最佳时机。因此，星火</span><span style=\"font-family:微软雅黑;font-size:12pt;\">教育</span><span style=\"font-family:微软雅黑;font-size:12pt;\">老师在这里要教给广大小学生和家长们五个有利于提高成绩的方法。</span><span style=\"font-family:微软雅黑;font-size:12pt;\"></span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">&nbsp;</span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:28pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:14pt;font-weight:bold;\">1.</span><b><span style=\"font-family:微软雅黑;font-size:14pt;\">上课要积极主动</span></b><b><span style=\"font-family:微软雅黑;font-size:14pt;\"></span></b>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">积极主动的听课态度有利于调动起学生学习的兴趣。做好积极主动的听课态度准备，能够让学生的情绪处于稳定、集中和活跃的状态。</span><span style=\"font-family:微软雅黑;font-size:12pt;\"></span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">&nbsp;</span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:28pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:14pt;font-weight:bold;\">2.</span><b><span style=\"font-family:微软雅黑;font-size:14pt;\">课前预习</span></b><b><span style=\"font-family:微软雅黑;font-size:14pt;\"></span></b>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">小学生的注意力集中程度远远不如成年人，因此在40分钟的课堂上，极容易出现走神的情况，一走神就会落下重要的知识点。课前预习有利于防止这种情况的发生。在预习的时候，将不理解的知识点标记出来，在课堂上重点听这些疑难点。</span><span style=\"font-family:微软雅黑;font-size:12pt;\"></span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">&nbsp;</span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:28pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:14pt;font-weight:bold;\">3.</span><b><span style=\"font-family:微软雅黑;font-size:14pt;\">集中注意力</span></b><b><span style=\"font-family:微软雅黑;font-size:14pt;\"></span></b>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">俄罗斯教育家</span><a href=\"http://baike.baidu.com/view/97473.htm\"><span style=\"font-family:微软雅黑;font-size:12pt;\">乌申斯基</span></a><span style=\"font-family:微软雅黑;font-size:12pt;\">曾精辟地指出：“‘注意’是我们心灵的惟一门户，意识中的一切，必然都要经过它才能进来。”注意力是每个小学生都必须锻炼的一种能力。集中注意力要从平时做起，例如坐姿要端正，提起精神，坐如钟，立如松，走路一阵风；在上课的时候，要手、脑、嘴、眼全方位并用。调动起全身的感觉器官，去跟随老师的思路，投入学习中去。</span><span style=\"font-family:微软雅黑;font-size:12pt;\"></span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">&nbsp;</span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:28pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:14pt;font-weight:bold;\">4.</span><b><span style=\"font-family:微软雅黑;font-size:14pt;\">敢于提出问题</span></b><b><span style=\"font-family:微软雅黑;font-size:14pt;\"></span></b>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">在学习的过程中，要注重独立思考，切忌死记硬背。要理解老师传授的解题背后的思路方法，并且保持着向老师提问的倾向。在听课时，遇到不懂的问题，要做好标记，课后向老师提问。不放过任何一个疑点，多想多问。不要因为害羞而不敢提问，随意地过滤掉不懂的知识内容。</span><span style=\"font-family:微软雅黑;font-size:12pt;\"></span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">&nbsp;</span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:28pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:14pt;font-weight:bold;\">5.</span><b><span style=\"font-family:微软雅黑;font-size:14pt;\">学会记笔记</span></b><b><span style=\"font-family:微软雅黑;font-size:14pt;\"></span></b>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">记笔记除了能够集中注意力外，还能更好地帮助学生梳理知识线索，有利于课后的复习。但是有很多同学上课只顾着抄笔记，却没认真听讲。上课抄笔记不追求抄得一模一样，而是在理解了老师的讲课内容后，自己把知识点归纳下来。</span><span style=\"font-family:微软雅黑;font-size:12pt;\"></span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<img title=\"星火教育\" alt=\"星火教育\" align=\"\" src=\"http://file.xinghuo100.com/upload/25/924/934/953/image/20160927/20160927230621_9135.jpg\" width=\"550\" height=\"364\" /><span style=\"font-family:微软雅黑;font-size:12pt;\">&nbsp;</span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;text-indent:24pt;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">&nbsp;</span>\r\n</p>\r\n<p class=\"MsoNormal\" style=\"color:#666666;font-family:&quot;font-size:16px;background-color:#FFFFFF;\">\r\n	<span style=\"font-family:微软雅黑;font-size:12pt;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 以上就是星火</span><span style=\"font-family:微软雅黑;font-size:12pt;\">教育</span><span style=\"font-family:微软雅黑;font-size:12pt;\">老师帮助小学生养成良好学习习惯，提高小学成绩的五大小秘诀。希望家长</span><span style=\"font-family:微软雅黑;font-size:12pt;\">赶紧</span><span style=\"font-family:微软雅黑;font-size:12pt;\">督促孩子改掉坏习惯吧。将这五大学习方法掌握起来吧！</span>\r\n</p>', '', '0');

-- -----------------------------
-- Table structure for `onethink_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_download`;
CREATE TABLE `onethink_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `onethink_file`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_file`;
CREATE TABLE `onethink_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `onethink_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_hooks`;
CREATE TABLE `onethink_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_hooks`
-- -----------------------------
INSERT INTO `onethink_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `onethink_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop');
INSERT INTO `onethink_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment');
INSERT INTO `onethink_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment');
INSERT INTO `onethink_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '');
INSERT INTO `onethink_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment');
INSERT INTO `onethink_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor');
INSERT INTO `onethink_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `onethink_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam');
INSERT INTO `onethink_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor');
INSERT INTO `onethink_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '');

-- -----------------------------
-- Table structure for `onethink_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_member`;
CREATE TABLE `onethink_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `onethink_member`
-- -----------------------------
INSERT INTO `onethink_member` VALUES ('1', 'Administrator', '0', '0000-00-00', '', '10', '9', '0', '1476023891', '1879436323', '1476107610', '1');
INSERT INTO `onethink_member` VALUES ('2', 'admin', '0', '0000-00-00', '', '10', '3', '0', '0', '2130706433', '1476089150', '1');

-- -----------------------------
-- Table structure for `onethink_menu`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_menu`;
CREATE TABLE `onethink_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_menu`
-- -----------------------------
INSERT INTO `onethink_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('2', '内容', '0', '2', 'Article/mydocument', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0');
INSERT INTO `onethink_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0');
INSERT INTO `onethink_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('16', '用户', '0', '3', 'User/index', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0');
INSERT INTO `onethink_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0');
INSERT INTO `onethink_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0');
INSERT INTO `onethink_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0');
INSERT INTO `onethink_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0');
INSERT INTO `onethink_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0');
INSERT INTO `onethink_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0');
INSERT INTO `onethink_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0');
INSERT INTO `onethink_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0');
INSERT INTO `onethink_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0');
INSERT INTO `onethink_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0');
INSERT INTO `onethink_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('43', '扩展', '0', '7', 'Addons/index', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0');
INSERT INTO `onethink_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0');
INSERT INTO `onethink_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0');
INSERT INTO `onethink_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0');
INSERT INTO `onethink_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0');
INSERT INTO `onethink_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0');
INSERT INTO `onethink_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0');
INSERT INTO `onethink_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0');
INSERT INTO `onethink_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0');
INSERT INTO `onethink_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0');
INSERT INTO `onethink_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0');
INSERT INTO `onethink_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0');
INSERT INTO `onethink_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '网站属性配置。', '', '0');
INSERT INTO `onethink_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('68', '系统', '0', '4', 'Config/group', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0');
INSERT INTO `onethink_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0');
INSERT INTO `onethink_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0');
INSERT INTO `onethink_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0');
INSERT INTO `onethink_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0');
INSERT INTO `onethink_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0');
INSERT INTO `onethink_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0');
INSERT INTO `onethink_menu` VALUES ('93', '其他', '0', '5', 'other', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('104', '下载管理', '102', '0', 'Think/lists?model=download', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('105', '配置管理', '102', '0', 'Think/lists?model=config', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `onethink_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0');

-- -----------------------------
-- Table structure for `onethink_model`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_model`;
CREATE TABLE `onethink_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `onethink_model`
-- -----------------------------
INSERT INTO `onethink_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', 'id:编号\r\ntitle:标题:article/index?cate_id=[category_id]&pid=[id]\r\ntype|get_document_type:类型\r\nlevel:优先级\r\nupdate_time|time_format:最后更新\r\nstatus_text:状态\r\nview:浏览\r\nid:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"2\",\"5\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题:article/edit?cate_id=[category_id]&id=[id]\r\ncontent:内容', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('4', 'teachers', 'teachers', '0', '', '1', '{\"1\":[\"33\",\"34\",\"35\",\"36\",\"37\",\"38\",\"39\"]}', '1:基础', '', '', '', '', 'id:编号id\r\nname:姓名\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', '', '', '1476073846', '1476098941', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('5', 'school', 'school', '0', '', '1', '{\"1\":[\"50\",\"51\"]}', '1:基础', '', '', '', '', 'id:编号id\r\nSchoolName:学校名称\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', '', '', '1476101131', '1476102489', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `onethink_picture`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_picture`;
CREATE TABLE `onethink_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_picture`
-- -----------------------------
INSERT INTO `onethink_picture` VALUES ('1', '/Uploads/Picture/2016-10-10/57fb180d70d15.jpg', '', '924bc736607d40829af6a1f1b02c00d8', 'be7eea8286698f60d8cb1473f1ab9732fdffec8e', '1', '1476073484');
INSERT INTO `onethink_picture` VALUES ('2', '/Uploads/Picture/2016-10-10/57fb77a5b1e5d.jpg', '', '4cf164018ddf13f2489e08d3fdecddd6', '7483c824c90a670ab8ba05494c8d41ea7f64d204', '1', '1476097957');
INSERT INTO `onethink_picture` VALUES ('3', '/Uploads/Picture/2016-10-10/57fb78ac58c64.jpg', '', '12b3dd273c415d63841c01a4dd267ebe', '72f7b3ea2c3ffa6bcd94d0aa2f35d551785b4a0f', '1', '1476098220');
INSERT INTO `onethink_picture` VALUES ('4', '/Uploads/Picture/2016-10-10/57fb7a162d1fa.jpg', '', '1804b3f0fe1f58600a70bc76bcf5dd15', '0c9d3d5cb0da2b30ed91ce37c898d4150d45dcf3', '1', '1476098582');
INSERT INTO `onethink_picture` VALUES ('5', '/Uploads/Picture/2016-10-10/57fb7a54df427.jpg', '', '2fc47e935684aedbdf8738f61e508faa', '4fe3602fca1dcadace1950078d6acccfcd6257ee', '1', '1476098644');
INSERT INTO `onethink_picture` VALUES ('6', '/Uploads/Picture/2016-10-10/57fb7aac9a95d.png', '', '242da2f01b42441ec2777a917e3bb440', 'b55641167a43138c4475b4712321b174298b14c3', '1', '1476098732');
INSERT INTO `onethink_picture` VALUES ('7', '/Uploads/Picture/2016-10-10/57fb7ae7e3e1d.jpg', '', '7cf6b22de8f2a159675335d496d76329', '8040adb26f851d6107098c1d47cf638a71290941', '1', '1476098791');
INSERT INTO `onethink_picture` VALUES ('8', '/Uploads/Picture/2016-10-10/57fb7b467ba4b.jpg', '', '70bdb20f4dbb1413e986bb419b24e97b', '4de6c4ab64a4e3b10a6f9a8689ee0672dfe7228f', '1', '1476098886');
INSERT INTO `onethink_picture` VALUES ('9', '/Uploads/Picture/2016-10-10/57fb818d241d3.png', '', '49b955a8b86f709cab18de072eef62c5', '51cc26e676ffcfcdac90284bf620cbcfeb05fbfe', '1', '1476100492');
INSERT INTO `onethink_picture` VALUES ('10', '/Uploads/Picture/2016-10-10/57fb81d0cff3d.png', '', '9adf7ac800f5269c8a00633a5c5f0945', '2baa5d883d45cd7fa9fa210813321a83ea70c224', '1', '1476100560');
INSERT INTO `onethink_picture` VALUES ('11', '/Uploads/Picture/2016-10-10/57fb822864c5c.png', '', '98a3204f1817b50bccf7dfd28a5f841c', 'a9b06f931ea9ade43059792a0c57bc22f4496392', '1', '1476100648');
INSERT INTO `onethink_picture` VALUES ('12', '/Uploads/Picture/2016-10-10/57fb8db2cc1c6.jpg', '', '09b62bf72556c67223c79d72995e2c51', 'aeb89e6a96cfb0adb94b63996d9cf53acd140325', '1', '1476103602');
INSERT INTO `onethink_picture` VALUES ('13', '/Uploads/Picture/2016-10-10/57fb8e214ed7b.png', '', '67df1e9f27c204133ce24ae87eed1340', '2a4cc1a768fe94476b6b53be92115893fafe23fd', '1', '1476103712');
INSERT INTO `onethink_picture` VALUES ('14', '/Uploads/Picture/2016-10-10/57fb8e9210f55.jpg', '', 'cb1d2a55336c01de273d25f0c24dade7', '24e347ee9be9dedf1bf35ac2e18970d15ed47210', '1', '1476103825');
INSERT INTO `onethink_picture` VALUES ('15', '/Uploads/Picture/2016-10-10/57fb8ee5ce4c3.jpg', '', '25f5ae0548a97956fb6b204c9bbfc3da', '8b328bd93c1abea953b75dbd85958c7543d33e8f', '1', '1476103909');
INSERT INTO `onethink_picture` VALUES ('16', '/Uploads/Picture/2016-10-10/57fb8f69076a4.jpg', '', 'f82a1a7c68a437f67dca152b4f7ba0a8', '729eb060909cb98916f5656c7cc3ff6e357cb19e', '1', '1476104040');
INSERT INTO `onethink_picture` VALUES ('17', '/Uploads/Picture/2016-10-10/57fb8fbd34776.png', '', '7274876a3c0f992bf994dea8ac2b4a56', 'e730f807211445709d96706a6a1641589ce5eb0b', '1', '1476104123');
INSERT INTO `onethink_picture` VALUES ('18', '/Uploads/Picture/2016-10-10/57fb904ec986f.jpg', '', 'bc1c9ba4c0e1be53bc9c0482973d3f85', 'f7ead3a1307a69d87f48694f9cd90369f933223a', '1', '1476104270');
INSERT INTO `onethink_picture` VALUES ('19', '/Uploads/Picture/2016-10-10/57fb90b75c693.jpg', '', '58fb7a7dd0e0cb2db113e70872b5ec48', '5f79bedbaae4d1f05168a865be469327643c1577', '1', '1476104375');
INSERT INTO `onethink_picture` VALUES ('20', '/Uploads/Picture/2016-10-10/57fb926b0a42e.jpg', '', 'f017249591e9d63e8fd43cc8d7bf6e16', '710be296f832f192c09ac38cf273980e49903eb2', '1', '1476104810');
INSERT INTO `onethink_picture` VALUES ('21', '/Uploads/Picture/2016-10-10/57fb92cb197f4.jpg', '', '97bd7c84cb7ff0180043e73937d482d0', 'e5e8152228d8bcfdd43ae7d3fa0e79139b9af654', '1', '1476104907');

-- -----------------------------
-- Table structure for `onethink_school`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_school`;
CREATE TABLE `onethink_school` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `SchoolName` varchar(255) NOT NULL COMMENT '学校名称',
  `UrbanDistrict` varchar(255) NOT NULL COMMENT '城市区域',
  `SchoolType` varchar(255) NOT NULL COMMENT '学校类别',
  `SchoolNature` varchar(255) NOT NULL COMMENT '学校性质',
  `time` varchar(255) NOT NULL COMMENT '创办时间',
  `website` varchar(255) NOT NULL COMMENT '学校网址',
  `phone` int(10) unsigned NOT NULL COMMENT '联系方式',
  `address` varchar(255) NOT NULL COMMENT '校区地址',
  `introduce` text NOT NULL COMMENT '学校介绍',
  `level` varchar(255) NOT NULL COMMENT '学校级别',
  `picture` int(10) unsigned NOT NULL COMMENT '图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `onethink_school`
-- -----------------------------
INSERT INTO `onethink_school` VALUES ('1', '福州华伦中学', '福州市', '仅初中', '民办', '1994年', 'http://www.fzhlzx.com.cn/', '0', '台江区；晋安区', '在商潮流溢的台江闹市、在美丽的闽江畔有这么一块格外清新的文化热土，它就是福州华伦中学，诞生于1994年。华伦中学办学以来白手起家，艰苦创业，一年一座楼，十年成景观；上下求索，开拓创新，构建华伦的办学特色，走出一条适合自己发展的路，为一批又一批慕名而来的求学者打造了一方育人天地。华伦中学有两个校区：台江校区的地址在五一南路、国货西路、达道路与广达路之间的台江区上墩里3号，毗邻福州市国货路小学；晋安校区地址在福兴大道33号，毗邻鼓岭。学校连续十五届在福州市毕业生“四率”评比中获得优胜奖，中考成绩连续多年名列前茅，在2014年福州中考中，平均分、一三附录取率、一级达标校录取率均为第一，学校达到了一个新的台阶。台江校区为走读制校区，晋安校区以寄宿制为主。\r\n\r\n近些年来，学校办学成果显著，在福州市享有良好声誉。今后，学校将传承优良，继往开来，不辱使命，不负众望，继续为办成一所“校风良好、环境优美、设施先进、质量一流、特色突出”的名校，办好人民所需要的满意、放心的教育而努力奋斗！\r\n\r\n台江校区\r\n学校不断美化校园环境，优化办学条件。到2015年已拥有四幢功能齐全、设施配套的教学楼、综合实验楼以及理化生实验室、语音室、电脑室、演播室、多媒体投影室等各类专用教室。学校所有教室都配有电脑、彩电、空调、投影仪，并实现校内电脑联网，充分体现了现代教育的特征。\r\n\r\n晋安校区\r\n目前有三个年段，18个班级。设备完善的教学楼，一座老师的办公楼，干净整洁的餐厅，礼堂，两座学生宿舍，一座老师宿舍及各科实验室等。每一间教室均配有电脑、投影仪等现代化教学设备。\r\n\r\n学校坚持走“依法办校、以德治校、科研兴校、质量强校”的路子，全面推进素质教育，连续八届毕业班“四率”在全市名列前茅，每年约有70%的毕业生进入重点高中。培养了大批品学兼优、学有特长的学生，有259名学生在全国、省、市各学科竞赛中获奖。特别是郑暾，吴晓悦同学2013年被评为第四届“福建省小科学家”，这是全省初中生中仅有的两位。学校荣获“福州市文明学校”、首批“福州市民办A级达标学校”、“福建省小公民道德建设先进集体”等多项荣誉。\r\n\r\n学校实行董事会领导下的校长负责制，学校董事长为林捷冬，校长戴俊是福建省民办教育协会副理事长、福州市民办教育协会理事长，原为福州八中校长，具有近20年重点中学校长工作经验，思想解放，敢于创新，工作业绩昭著，曾荣获全国劳模、全国先进教师、省市劳模等多项荣誉。学校建立了党支部和工会组织，党支部书记、工会主席罗寅是福州市教育界资深人士，原为福州师专党委书记，有丰富的学校领导工作经验。党政班子团结进取，励精图治，深得全体师生信赖。学校规章制度健全，管理严格规范，教育教学工作高效有序运行。\r\n', '市一级', '12');
INSERT INTO `onethink_school` VALUES ('2', '福州一中', '初中部：福州市鼓楼区/高中部：闽侯县', '初中+高中', '公办', '1817年', 'http://www.fzyz.net/', '0', '初中部：鼓楼区东街66号/高中部：闽侯大学城', '福州第一中学（Fuzhou No.1 High School）是福建省教育厅管理的中学，全国文教系统先进单位，福建省文明学校，全国中小学现代教育技术实验学校，福建省奥林匹克教育特色学校；创办于1817年。\r\n\r\n师资力量：截至2014年，共有教职工约200余人，高级教师占教师总数的46%，其中有福建省优秀专家2人，享受国务院特殊津贴专家5人，全国模范教师、优秀教师6人，特级教师34人（含已退休），省级中青年学科带头人及培养对象19人。\r\n \r\n历年中考分数线\r\n福州一中历年录取分数线\r\n \r\n正取\r\n定转统\r\n择校\r\n2013\r\n514\r\n508\r\n504\r\n2014\r\n511\r\n504\r\n501.5\r\n2015\r\n511.5\r\n505\r\n \r\n15年中考取消择校生的招生，因此只有正取分数线和定转统分数线。\r\n招生程序上是先招统招生，再招报考第一志愿的定向生，未招满的定向生剩余指标调整为统招生指标，进行统招生第二次录取。\r\n \r\n历年高考成绩\r\n2015年高考成绩：\r\n本一上线情况：理科本一上线率96.41%。文科本一上线率90.70%。综合文理科，本一上线率为95.29%。\r\n \r\n2014年高考成绩：\r\n理科本一上线率98.4%；文科本一上线率98.5%；综合文理科，本一上线率为98.42%。理科600分以上的高分人数有357人，占理科考生的58.81%；文科600分以上的高分人数有110人，占文科考生的71.90%。\r\n \r\n2013年高考成绩：\r\n本一上线率率文理综合95%，文理科600分以上的共有256人。\r\n', '省一级', '13');
INSERT INTO `onethink_school` VALUES ('3', '福州外国语学校', '福州市仓山区', '初中+高中', '公办', '1907年', 'http://www.fzwgyxx.com/', '0', '福州市仓山区公园路39号', '福州外国语学校坐落于风景秀丽闽江南岸文化教育区--仓山区，校门前的公园路绿树成荫。学校创办于1907年，有108年的悠久历史。学校前身为福州\"三一学校\"、\"福州第九中学\"，是福州市唯一的公立外国语学校，当地市民多称为\"九中\"。学校是福建省普通中学一级达标学校，全日制普通完全中学。\r\n\r\n   坐落于福州市仓山区公园路39号，前身是爱尔兰都柏林三一学院创办的私立教会学堂，福州三一学校;1952年10月，由福州市政府接办为一所新型的公立学校，定名为福州第九中学。1993年6月人民政府颁文更名为福州外国语学校。2004年被授予福建省普通中学三级达标学校，2006年被授予福建省普通中学二级达标学校，2015年被授予福建省普通中学一级达标学校。\r\n \r\n   福州外国语学校是福州市属唯一的一所公立外国语学校，学校现有校园面积29726平方米(约45亩)，建筑面积29496平方米。校园布局合理，环境优美，拥有\"思万楼\"、\"俄国领事馆\"等国家保护的文物保护建筑，校园中\"晨辉园\"、\"春华园\"、\"启明雕塑\"、\"硕果雕塑\"等亭、园、雕塑，掩映在巨榕花草丛中，是市级花园式单位。师资力量雄厚，现有教职员工 203人，其中高级教师60人，中级教师67 人，3位教师具有硕士学位。目前有56个教学班，在校生2710人。\r\n\r\n   作为福州外国语学校前身的福州三一学校，创办于1907年，一百多年来，学校为高等院校和社会各界培养和输送数以万计的优秀学生和建设人才。老一辈校友中有以陈景润、陈哲人、王岳、谢冕等为代表的科教文卫事业发展做出重大贡献的科学家和学者，大批中青年校友正成长为祖国各条建设战线的栋梁之材。\r\n\r\n   2010年经德国政府批准，该校开设德语班，是经德国教育部授牌的合作项目，是福建省继厦门外国语学校之后第二所具有相应资格的学校，学生在中学六年的学习阶段德语能够达到DSD-C1级别，国内高考达到本一录取线，就可申请就读德国的优质公立大学(学费全免)，省内外外国语学校报考德国大学的成功率达100%。德语班办学目标就是为德国优质公立高等院校输送优秀毕业生。', '省一级', '14');
INSERT INTO `onethink_school` VALUES ('4', '福州高级中学', '福州市仓山区', '仅高中', '公办', '1951年', 'http://www.fugaofj.net/', '0', '福州市仓山区乐群路18号', '福州高级中学创办于1951年，曾名“福建省工农速成中学”，1956年定名为“福州高级中学”，1969~1978年更名为“贮木场工农子弟中学”，1978年恢复为“福州高级中学”，并被省教育厅确定为省首批重点中学，1996年1月被省教委确认为“福建省普通中学一级达标学校”，2006年被确认为“福建省普通高中新课程实验样本校”。\r\n\r\n师资力量 \r\n学校师资力量雄厚，名师云集。截止2015年1月，学校在编教职员工152人，其中正高级教师1名，特级教师5名，高级教师占教师总人数52.3%。独占省市基础教育鳌头的福建省中小学教学名师2名、福建省学科带头人15名、福州市名学科带头人3名，教育部“国培计划”专家库人选1名、教育部全国中小学教师信息技术应用能力提升工程专家库成员1名，福建教育学院兼职教授4名，福建师大兼职教授1名、兼职教授副教授10名，福州市中学政治和中学历史2个“名师工作室”落户福高。\r\n\r\n教学建设\r\n学校地处烟台山之巅，校园环境清幽，是学子求学的理想所在。学校现有36个教学班，学生近2000人，教职工约158人。校园现占地34289.1平方米，绿化面积3847.59平方米，建筑面积28380平方米。错落有致的建筑群，构成了校园的一道风景线：崭新的办公综合楼、食堂、教工住宅楼、两个塑胶田径场、篮球场、排球场、教工健身房、焕然一新的图书馆、体操馆、设备齐全的教学综合楼、实验楼、学生宿舍楼等掩映在树影花丛之中。学校有着一流的教学设施，拥有计算机网络教室、电子阅览室、教工电脑备课室和多媒体教室、多媒体会场等。\r\n福州高级中学历年录取分数线\r\n \r\n正取\r\n定转统\r\n择校\r\n2013\r\n476\r\n473\r\n \r\n2014\r\n478\r\n471\r\n472.5\r\n2015\r\n484\r\n478\r\n \r\n高考成绩：\r\n2014年：2014年高考本科上线率达97.8%，本一上线率接近50%。', '省一级', '15');
INSERT INTO `onethink_school` VALUES ('5', '福州三牧中学', '福州市鼓楼区', '仅初中', '民办', '1995年', '福州一中网站右侧三牧专栏', '0', '福州市鼓楼区江厝路，毗邻福飞南路', '福州三牧中学，现坐落于福州市鼓楼区风景秀丽的五凤山麓的江厝路，毗邻福飞南路。是一所由百年名校－－福建省福州第一中学（以下简称福州—中）于1995年（1997年停办， 2001年复办至今）独自创办的民办初级中学。作为实践福州一中办学理念的窗口，三牧中学秉承福州一中的优良传统，以福州一中“植基立本、成德达才”和“勤奋、严谨、活跃、竞取”作为学校的校训、校风，并承担为福州一中高中输送优质生源的任务。\r\n\r\n2003年初，学校被评为福州市首批A级民办中学。\r\n2005年学校被福州市教育局授予“福州市素质教育先进学校”荣誉称号；被福建省民办教育协会、福建省中小学幼儿教师奖励基金会授予“福建省民办教育先进单位”荣誉称号；荣获“福州市民办教育‘A级’学校”荣誉称号。2008年、2009年，福州市中考状元均来自福州三牧中学。2014年，福州市中考前六全部来自三牧，前十名中三牧占了八席。\r\n\r\n学校十分重视教师队建设，目前已拥有一支力量雄厚且非常优秀的师资队伍（全校90余名教职工中，有特级教师4名，本科及本科以上学历占总数的90%以上），教师中曾有多人、多次（含指导学生）在国际、国家、省、市级比赛中获奖，如：杨卫民老师获得第五届全国直辖市/省会城市中学语文青年教师教学大赛中荣获一等奖；张气老师指导学生李竞欣参加第20届全国青少年科技创新大赛获得二等奖；左名淼老师在第十五届“希望杯”全国数学邀请赛中教学成绩优异，被评为“数学教育优秀园丁”……\r\n\r\n该校连续三届中考成绩卓著。\r\n2004年（系该校复办以来的第一届毕业生）中考：218名学生，共有63人先期考上福州一中新校区（在全省范围招生），居全省第一名。其余155名考生参加福州市中考，总平均分（除考上福州一中新校区63人外、不含体育）达632.59，且仍有63人考上福州一中东街校区等一级达标学校，占考生总数的40.6%，名列福州市前茅。 2005届中考：200多名学生，400分（高分段）以上考生共102人，被一级达标校录取的考生共计136人（占62%），其中被福州一中录取的考生达70多人。名列福州市前茅。 2006届中考：207名学生，400分以上124人（高分率达59.9%），考上一级达标校的计有163人（占总数的78.7%），其中被福州一中录取的更是高达82人之多，比率40%为福州市绝无仅有。 2007届中考：309名学生，400分以上106人，已被一级达标校录取的共有222人，其中被福州一中录取的人数高达114人。 2008届中考：415名学生，400分以上317人，410分以上247人（全市2909人），415分以上195人（全市1966人），420分以上156人（全市1155人），430分以上32人（全市169人）。其中考入福州一中人数高达147人，被一级达标校录取334人。陈正颖同学以444.5分夺得福州市最高分（语数英三科原始分439.5，省运会乒乓球冠军加5分）。各项数据都居福州市第一。 2009年，江川同学以443.5分勇夺中考状元，为09届八班赢得荣誉。2010年，考入福州一中88人。2012年，全市总排名第二，其中考上一中人数137人，全市第一。2013年，三牧中学中考成绩500分以上的人数有168人，约占年段总人数的35%，全市总排名第一。2014年，我校学生勇夺中考状元、榜眼、探花，同时包揽了福州市中考成绩前六名，前九名中占有八席,只有第七名为福州一中初中部学生董焌锴获得。一所学校几乎包揽了全市中考的前十名在福州市是绝无仅有的。\r\n中考成绩525分以上全市累计13人，三牧中学有11人\r\n中考成绩520分以上全市累计59人，三牧中学14人；占比24%\r\n中考成绩515分以上全市累计180人，三牧中学35人；占比19%\r\n三牧中学被福州一中录取106人，人数依旧为全市之最；被福州三中录取43人；被师大附中录取28人……\r\n\r\n发展提升实力，实力铸造辉煌。伴随教育春天的脚步，沐浴时代的春风，新时期的三牧人正以昂扬的意志，奋发有为的精神风貌，扎实工作，继往开来，与时俱进，扬起理想之帆，创造更加美好的明天！', '市一级', '16');
INSERT INTO `onethink_school` VALUES ('6', '福州第十九中学', '福州第十九中学', '初中+高中', '公办', '1951年', 'http://www.fz19.com.cn/', '0', '鼓楼区庆城路16号', ' 学校建校于1951年，占地面积13866.53平方米，截至2013年9月，该校有学生三千余人，教师一百多人，班级54个，其中初一年级有21个班，初二有18个班，初三有15个班。 现任校长林远达。 福州第十九中学，福建省青少年科技教育重点示范点，二零零三年荣获福州市科技示范学校。自1986年起到2006年，共有近90名学生的科技发明、科幻画在省市级，国家级乃至国际科技发明比赛中获得大奖。\r\n\r\n  该校系福建省普通初中示范学校，在近五十年的办学历程中，始终坚持“依法治校，改革活校，科研兴校，特色立校”的发展举措，取得了令人瞩目的成绩。自初招改革以来连续五届中考高分率、优秀率均名列全市前茅，培养了两届福州市中考状元，连续五年荣获初中综合比率达标单位先进表彰。五年中累计将1295位优秀学子送入省、市一级达标校，其中510位学生被福州一中、三中、师大附中录取，785位学生被格致、二中等其他五所一级达标校录取。更有不少佼佼者在高中期间被保送至北大、清华等著名大学学府。创办至今学校先后荣获全国“开辟多种渠道，培养新型人才，活跃的中学生活动先进学校”、全国教育科学“十五”规划课题先进实验学校、福建省教育先进单位、福建省科普工作先进集体、福州市文明学校、福州市实施素质教育工作先进学校、福州市教育收费规范学校等称号。\r\n  \r\n   学校现有教职工174人，其中专任教师156人，其中研究生学历13人，本科以上学历教师占90%，中、高级教师占三分之二，另有1位省级学科带头人，4位省级骨干教师，3位市级骨干教师培训班导师，3位市级教研员，9位市级骨干教师。学校还拥有获得全国、福建省优秀科技辅导员，福建省五一劳动奖章获得者，福建省师德标兵，福建省先进德育工作者，福建省优秀班主任等荣誉的一大批优秀教师。学校还有十多位教师直接参与了中考命题工作。\r\n\r\n  该校是福建省青少年科技教育重点示范点，并首批被命名为福州市科技教育示范学校，科技教育已成为我校实施素质教育的突破口，并形成鲜明的办学特色。在国家级科技创新大赛中，我校学生累计获得6枚金牌、7枚银牌、7枚铜牌，并囊括了“宋庆龄基金奖”、“王丹萍基金奖”、“佐藤明雄奖学金”、“光华科技基金奖”和“中信青少年发明奖”等多项专项奖，省、市级奖次共计100多项。', '市一级', '17');
INSERT INTO `onethink_school` VALUES ('7', '黎明中学', '福州鼓楼区', '初中+高中', '民办', '1993年', 'http://www.fzlmzx.com/', '0', '福州市鼓楼区斗池路62', ' 福州黎明中学创办于1993年，现有初、高中30个班。2002年评上福州市民办学校首批A级校，福州市初中综合比率达标单位，2003年、2005年连续评上福州市文明学校，2005年又被评为福州市中小学实施素质教育工作先进学校、福建省民办教育先进单位、连年评上福州市初中巩固率、报考率、及格率、全科及格率先进单位。\r\n\r\n   学校环境优美，教学设施齐全，师资力量雄厚、管理规范有序，学校附设有青少年素质教育基地--黎明中学地球村。多年来，黎明中学坚持“以德树人、以质立校”的办学宗旨，在全体教师中形成“敬业乐教、勤勉治学、热爱学生、无私奉献”的良好教风，努力培养学生成为品行端正、人格健全、身心健康、基础扎实、思维活跃、善于学习、主动发展的新型人才。办学思想：目标：“优质初中加特色高中”；校训：“勤奋、严谨、求实、进取”；宗旨：以德树人、以质立校。\r\n\r\n\r\n  黎明中学创办以来，教学质量始终名列全市初中校前列。每年为省一类达标重点学校输送了大量品学兼优的学生，2003年、2004年、2005年连续三年，黎明中学陈云从、陈龙、莫琳三位同学分别以全市最高分成为当年福州市中考状元。黎明中学学生每年在各级学科竞赛中取得显著成绩，近年来在国际竞赛中获奖7 项、国家级竞赛获奖64项，省级竞赛获奖43项、市级竞赛获奖581项。黎明中学优良的校风、学风、高质量的教学得到了家长和社会的广泛赞扬。\r\n\r\n   黎明中学认真学习贯彻十六大精神，以\"三个代表\"重要思想为指导，继往开来、开拓创新、与时俱进。2003年9月开办特色高中—剑桥高中部，2005年9月开办普通高中，使黎明中学成为既有优质初中又有特色高中的完全中学，为学校的持续发展开创了崭新的局面。', '市一级', '18');
INSERT INTO `onethink_school` VALUES ('8', '福州时代中学', '福州市仓山区', '仅初中', '民办', '1994年', 'http://sd.fjsdfz.org/', '0', '福州市仓山区程埔路172号', '福州时代中学是1994年由福建师大附中创办的一所民办学校。位于仓山区程埔路172号新校园内（原福建师大生命科学院校址，与福建师大附中毗邻。学校办学规模逐年扩大，从开办初期的初一两个班110位学生发展到现在，全校从初一到初三共36个班级（现2017级、2016级各12个班，现2015级12个班），学生2036 人，成为一所普通全日制完全中学。2015年学费一年一万三千元。（不包括学杂费）。\r\n\r\n学校现有教职工133人，其中专任教师117人。师资队伍的老、中、青结构合理，现有高级教师44人，具有硕士学位的3人。学校教学设备基本达到要求，目前初中部独立校区的专用教室中有物理实验室4间，化学实验室2间，生物实验室2间，劳技教室2间，美术、音乐教室各2间，有7间专用教室装备了多媒体设备，装备有54联网电脑的计算机教室一间。学校已建成校内局域网，并联入电信宽带网，适应教育教学工作的需要。2006年学校迁入程埔路新校区后，各方面条件将进一步完善。在2009年新学期，迁至原福建师范大学生物研究系。\r\n\r\n截止2014年，福州时代中学连续17年蝉联福州市中考成绩第一名。\r\n2015年，福州时代中学高怡丹、蔡凌晟同学分别取得福州市中考榜眼，探花。\r\n2013年，福州时代中学陈崇松同学取得福州市中考状元\r\n2003年初，学校被评为福州市首批A级民办中学；\r\n2005年初，获福州市《素质教育工作先进校》称号；\r\n2005年7月，获福建省民办教育先进单位称号。\r\n2003年全国青少年信息学奥林匹克联赛（NOIP2003）组委会授予学校“优秀参赛学校”荣誉称号。\r\n2004年全国少工委授予该校“民族精神代代传，爱国百分百活动”组织奖。\r\n2003年，该校初一、二年级的52位学生，参加中央电视台春节特别节目《智取博士山》的录制工作，获中央电视台颁发的节目“创意奖”；初二学生郑頔在第九届“雨花杯”全国中学生作文大赛中获一等奖，到北京大学受奖；高二学生练轩云参加福建省“航空百年知识竞赛”成绩突出，入选全国“百名航空少年”，晋京参加全国纪念国际航空百年活动，并参加与航天英雄杨利伟的座谈会。\r\n2004年，初三学生王宇凡同学获19届省青少年科技创新科幻画一等奖；该校高三理科班学生邓时滨参加全省高中化学奥林匹克竞赛，荣获一等奖；初二学生赵叶烨在参加福州市第20届青少年科技创新大赛中，荣获一等奖。\r\n2005年，杜NOIP2005（信息学竞赛）福建赛区中该校唐浩、林一施、朱宏佳、郑发魁、陈声远等5人获一等奖，另有二等奖5人，三等奖4人；初一学生黄一林在第十届“华罗庚杯”和第十六届“希望杯”全国数学邀请赛上，两次均获福州赛区第一名；在福州市第21届青少年科技创新大赛中，该校又有杨宏韬、林一施、吴则明、陈多等四位学生的四个项目获得一等奖；在NOIP2005（信息学竞赛）福州赛区中该校获奖人数名列前茅，共有18人在初中组获奖，其中陈声远、郑发魁、唐浩、肖忆南、黄辰等5人获一等奖5人，另有二等奖4人、三等奖9人；在福州市第十八届中学生现场风景绘画比赛中，我校两位学生林艳婷、黄博阳均获初中组一等奖，另有多人分获二、三等奖；在福州市第八届学生十佳歌手比赛中，该校初二学生林梦妍获初中组一等奖，并荣获“十佳歌手”称号；我校“红领巾合唱团”参加福州市第六届中小学生合唱节比赛，荣获初中组一等奖第一名。\r\n办学十二年来，学校确立“立德育才，全面发展”的办学宗旨，全面传承福建师大附中的优良校风和办学理念，从严治校，精心施教，以优良的校风和显著的办学质量，赢得社会的赞许和教育主管部门的肯定。', '市一级', '19');
INSERT INTO `onethink_school` VALUES ('9', '福州文博中学', '福州市鼓楼区', '初中+高中', '民办', '2006年', 'http://www.fzwbzx.com/wbwj/', '0', '福州市鼓楼区梁厝路171号', ' 福州文博中学（原福建师大文博附中）是福建金帝集团·仁文建设公司于2006年创办的一所民办完全中学，至今已有十年的历史。学校位于福州市鼓楼区梁厝路171号（仁文·大儒世家社区内），以“品学力行”为校训。\r\n \r\n     福州文博中学（原福建师大文博附中）是福建金帝集团·仁文建设公司于2006年创办的一所民办完全中学。学校占地80亩，校舍建筑4万多平米，有普通教室60间，各科实验室、专用教室、计算机教室共37间，均安装有多媒体教学设备；图书馆阅览室3500 平方米，藏书4万多册、报刊260余种；教学设施配置标准高，功能齐全。\r\n\r\n     校内有300米环形6道的塑胶田径场，5个塑胶篮、排球场等体育场地；有男、女生宿舍楼各一栋，配空调、供热水；食堂餐厅双层3000 平米；教学区走廊墙上张挂“国学”修身、明理、劝学名句60幅，校园中央有1万多平米的植物园景观区，树木成荫、环境优美；树有名人塑像10尊，文化氛围浓郁、布局自然和谐，是师生学习生活的理想场所。\r\n\r\n     学校依法办学、规范管理，从严治校、精心施教，德育为先、育人为本，注重核心价值观和行为规范的养成教育，为学有专长的学生提供良好的成长环境和发展机会。办学五年，形成的良好校风和学风得到省、市教育行政部门的好评和广泛的社会赞誉。2010年，先后有福建省“十一五”第六期校长培训班来校参观考察，有农村初中语文、政治科骨干教师教育教学能力提升工程省级培训班学员来我校观摩教学。\r\n\r\n     目前，全校初、高中六个年级45个教学班，在校生1800余人；全校教职工197人，其中专任教师139人，本科及以上学历95%；中级及以上职称51%，教师队伍爱岗敬业、团队力量强。学校设学生活动中心，学生会组建10个学生社团，培养自主自理能力；学校配专职保安24小时值班巡逻、出入登记，力保校园安全。\r\n\r\n     两届初中毕业生，中考平均分分别为694.8和710.6；中考优秀率分别为76.9%和74.7%（中招办数据），两年学校均获福州市“初中素质教育目标考评优胜学校”称号。两届高三高考，理科平均分均超本二线，文科平均分均超本三线；本二上线率分别为37.8%和50.4%，总上线率分别为95.7%和100%。\r\n\r\n     校团委获共青团市委颁发的《2009年度先进基层团组织》称号；校党支部获《2010年度福州市属教育系统先进基层党组织》称号；2010届高三有四位学生，经福州市教工委组织部考核发展为中共预备党员，成为文博中学培养的首批学生党员。', '普通级别', '20');
INSERT INTO `onethink_school` VALUES ('10', '福州励志中学', '福州市鼓楼区', '仅初中', '民办', '2003年', 'http://www.fzlizhi.com/', '0', '福州市鼓楼区梅峰路6号', '福州励志中学是2003年经福州市教育局批准，由福建省首批示范性高中——福州三中和福州国龙文化传播有限公司联合创办的一所民办初中学校。\r\n\r\n学校位于福州市鼓楼区梅峰路6号，环境优美。现有初中部三个年段，二十三个教学班。办学依托福州三中，利用其丰富的教育资源，以“励志、笃学、力行”为校训，坚持“以人为本，以诚为先，实现可持续发展”的办学理念，通过严格规范的管理、严谨求精的教风，培育优秀人才，满足社会对优质教育的需求，创办出有时代特性、有创新精神的学校。\r\n\r\n学校实行董事会领导下的校长负责制，由福州三中协助实施统一的教育教学管理。福州三中定期派出各学科带头人进行学科讲座，开展教研活动，并进行学科竞赛的指导工作。校园文化活动与福州三中同步。\r\n\r\n励志中学由福州三中高级教师余圣睦同志担任常务副校长兼法人代表。校长由福州三中语文特级教师、福州市首届“十佳教师”、福建省语文学会会长王立根同志担任。教学人员由福州三中富有经验的退休教师及部分招聘的优秀教师组成，教师队伍、敬业优秀。\r\n\r\n硬件设施：\r\n（1）配备16辆校车接送学生（初一初二和初三分车坐），尽职尽责。\r\n（2）学校食堂每日午餐准备四菜一汤，满足学生营养需求（可免费加饭）。如提供的饭菜不合胃口，教工食堂可自费加餐。\r\n（3）教室配备较齐全（含饮水机、电扇、投影仪）。初二五班、初二七班、初三全体教室配备空调。\r\n（4）学校拥有生物、化学、物理实验室，配有电脑。拥有音乐室，电脑室，配备钢琴、多媒体等教学设备，满足教学需要。\r\n（5）操场划分为升旗场和篮球场。\r\n（6）食堂附近开设小卖部（价格公道，课间可买零食）。\r\n（7）教学楼、行政楼每层均有男女洗手间。教学楼有3个楼梯，方便教室位置不同的学生进出。\r\n\r\n作息时间：\r\n早晨7：30前须到校。\r\n8：00——11：45为上午教学时间。（含下课休息10分钟，课间操30分钟，眼保健操5分钟）\r\n11：45——12：30为午餐、活动时间。\r\n12：30——13：15为静午休（午睡也可，初三年段同学强制午睡）时间。\r\n13：30——16：10为初一，初二年段下午教学时间。（含眼保健操5分钟，下课15分钟）\r\n13: 30——17: 20为初三下午教学时间。\r\n16：10为初一，初二放学时间。\r\n17: 20为初三放学时间。\r\n校车16：25左右出发（初三校车只有早上乘坐，下午校车在初一、初二放学时间开走）。\r\n校车为学校向康驰新巴士公司调取雇佣，共11辆校车，方便了住处离学校较远的同学上下学的接送。\r\n\r\n学校活动\r\n十佳歌手，运动会，元旦文艺汇演，体艺节，班班有歌声，班班有美展，社会实践等', '市一级', '21');

-- -----------------------------
-- Table structure for `onethink_teachers`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_teachers`;
CREATE TABLE `onethink_teachers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `grade` char(50) NOT NULL DEFAULT '0' COMMENT '年级',
  `subject` char(50) NOT NULL DEFAULT '0' COMMENT '科目',
  `head` int(10) unsigned NOT NULL COMMENT '头像',
  `name` varchar(255) NOT NULL COMMENT '姓名',
  `desc` text NOT NULL COMMENT '简介',
  `style` text NOT NULL COMMENT '教学风格',
  `achievement` text NOT NULL COMMENT '教学成果',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `onethink_teachers`
-- -----------------------------
INSERT INTO `onethink_teachers` VALUES ('1', '1', '2', '2', '刘冬', '具有丰富的教学经验，拥有自己独特简单的教学体系，启发式，发散式的教学风格，激发学生学习的兴趣，从而提高学生的成绩。', '1.根据不同年龄段的学生特点，因材施教。2.启发式教学，情景教学，让孩子参与到教学活动中来。3.注重学生的发散性思维，触类旁通，举一反三。', '针对学习内容，创造性地修改与设计课程，使之适合于学生的经历、兴趣、知识水平、理解能力和其他能力');
INSERT INTO `onethink_teachers` VALUES ('9', '1', '8', '9', '李杰', '对知识结构掌握全面，做事认真踏实，具有良好的协调沟通能力，适应力强，有亲和力，对学生有耐心，有强烈的责任感，喜欢分析问题并找到解决方案。', '导入自然、操练充分、重点明确、课堂气氛活跃、教态得体、声音洪亮、提问次数恰当', '\"教学期间，学生成绩提升率高达90% \"');
INSERT INTO `onethink_teachers` VALUES ('3', '2', '0', '3', '田艳', '认真仔细，能较好把握学生学习弱点，助其攻克弱势。有一套属于自己的教学模式。', '导入自然，重点明确，通俗易懂，幽默风趣。', '学生成绩稳步提高，学习更加积极主动');
INSERT INTO `onethink_teachers` VALUES ('4', '1', '8', '4', '冯圳楷 ', '自从进入星火之后，努力成为家长心目中的好老师，尽心尽力为学生服务，也努力为公司创造价值，提升自己的能力，让自己成为教学主任，我相信，越努力越幸运。', '幽默和专业性相结合，课堂风格不拘一格。', '初二学生李同学辅导了6次课之后从20多分提高到期末考60多分');
INSERT INTO `onethink_teachers` VALUES ('5', '1', '1', '5', '陈文建', '课堂深入浅出，条理清楚，层层剖析，环环相扣，论证严密，结构严谨', '对于各类考试命题规律的研究有着非常深入认识，在快速有效答题方面有个人独到见解。其独创理论体系，能在极短的时间内，使学生掌握标准化流程解题，深受欢迎。', '学生平均提分30分左右。所带学生大考进步率100%，学员家长满意度极高。');
INSERT INTO `onethink_teachers` VALUES ('6', '1', '1', '6', '范元辉', '丰富的学校教学经验，多年的一对一教学经验，对高考有深入的研究。对于课堂有很好的把控能力，能充分调动学课堂氛围，对于一对一能充分个性化辅导', '亦师亦友，与学生有比较良好的沟通，充分发挥针对学生个性化的教学，喜欢数学知识点进行串联，引导学生形成自己的知识系统，培养学生的数学思维能力', '所带学生的进步率96%以上，多名学生进入重点中学、重点大学');
INSERT INTO `onethink_teachers` VALUES ('7', '2', '0', '7', '吴春燕', '幽默亲和，知识讲解透彻，让学生在课堂中学友所乐，学友所乐，善于将学习融入情景中。', '授课过程深入浅出，形式灵活多样注重培养孩子自我学习能力，教会孩子学习方法，让学生花最少的时间和精力取得最佳的学习效果。', '让学生轻松应对语文学习，学生进步率95%以上，学生入学热门指定教师，深受学生喜爱和家长认可。');
INSERT INTO `onethink_teachers` VALUES ('8', '1', '1', '8', '刘海霞', '自封为龙华天桥最美女教师，为人亲和力强，擅于跟孩子做朋友， 言传身教。', '用活泼生动的方式走进孩子们的学习和生活，紧抓孩子的特点，针对性教学', '学生一个月内进步50分，星火龙华天桥最美女教师');
INSERT INTO `onethink_teachers` VALUES ('10', '1', '2', '10', '蒋世依', '从根本上掌握英语，构建英语语言逻辑框架，不仅在考试成绩上有提高，更能够真正应用英语。', '生动活跃的新课标教学模式、独特的提分方案、良好的组织教学能力、并具有独立的英语语法思维体系和构词体系，能够从根本上解决英语问题。', '近几年所带学生中考提分率超过92%；高考提分率超过90%。');
INSERT INTO `onethink_teachers` VALUES ('11', '1', '2', '11', '潘秋婷', '上课主要以学生的学习情况为主，结合学科特点，采取科学的教学方法，尽力营造轻松的学习氛围，培养学生的学习兴趣引导学生自主学习。', '针对性强', '近几年所带学生中考提分率超过93%；高考提分率超过89%。');

-- -----------------------------
-- Table structure for `onethink_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_admin`;
CREATE TABLE `onethink_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `onethink_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_app`;
CREATE TABLE `onethink_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `onethink_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_member`;
CREATE TABLE `onethink_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `onethink_ucenter_member`
-- -----------------------------
INSERT INTO `onethink_ucenter_member` VALUES ('1', 'Administrator', '06bb5f050b6d315f9a2a30ed274d3347', '120267583@qq.com', '', '1476023891', '2130706433', '1476107610', '1879436323', '1476023891', '1');
INSERT INTO `onethink_ucenter_member` VALUES ('2', 'admin', 'b4e7a06cb558dec7b7712a056dd4cd82', '1181586479@qq.com', '', '1476088752', '2130706433', '1476089150', '2130706433', '1476088752', '1');

-- -----------------------------
-- Table structure for `onethink_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_setting`;
CREATE TABLE `onethink_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `onethink_url`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_url`;
CREATE TABLE `onethink_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `onethink_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_userdata`;
CREATE TABLE `onethink_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

